<?php

// Set PDO parameters for database connection (Currently experiencing a problem so have fallen back to original connection type instead of PDO for now)

define('USER_NAME' , 'root');
define('PASSWORD' , 'Buck2fast');
define('CHAR_SET' , 'utf8');
define('DATA_BASE' , 'menucreator');
define('HOST_NAME' , 'localhost');

// Create DSN variable with the required information


// $dsn = "mysql:host='HOST_NAME';dbname='DATA_BASE';'set names utf8'"; 

// Set option attributes 

// $options = [

// 	PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, // Use exception mode for debugging
// 	PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // Set fetch mode to get associative arrays
// 	PDO::ATTR_EMULATE_PREPARES => false // Switch off emulate function as charset will be set by a parameter

// ];

// Create PDO object

//$pdo = new PDO($dsn, 'USER_NAME', 'PASSWORD', $options );




//Connect to the database using PDO object

$conn = mysqli_connect(HOST_NAME, USER_NAME, PASSWORD, DATA_BASE);

//Check if the connection failed and if so, display an error message
if (!$conn) 
{
die("Error: ".mysqli_connect_error());
}

