

function Template(input) 
{
	this.test = input;
	
	this.displayTemplate = function()
	{
		console.log(this.test)
		// console.log(section)
		// section.load('menutemplate.html #menucontainer', function()
		// {
			//addMenuData();
		// })
	}
}
